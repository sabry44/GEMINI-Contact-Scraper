
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { ExtractedContacts } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not found. Gemini API calls will fail.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "FALLBACK_KEY_IF_UNDEFINED" }); // Fallback to avoid crash if API_KEY is undefined, though it will fail API call
const model = 'gemini-2.5-flash-preview-04-17';

export const extractContactsFromText = async (text: string): Promise<ExtractedContacts> => {
  if (!API_KEY) {
    throw new Error("Gemini API key is not configured. Please set the API_KEY environment variable.");
  }

  const prompt = `
Analyze the following text and extract all unique email addresses and unique phone numbers.
Return the results as a JSON object with two keys: "emails" (an array of unique email strings) and "phoneNumbers" (an array of unique phone number strings).
If no emails are found, "emails" should be an empty array.
If no phone numbers are found, "phoneNumbers" should be an empty array.
Ensure phone numbers are reasonably formatted but prioritize extraction.

Text:
\`\`\`
${text}
\`\`\`

JSON Output:
`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.1, // Low temperature for factual extraction
      },
    });
    
    let jsonStr = response.text.trim();
    
    // Remove Markdown code fences if present
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }

    const parsedData = JSON.parse(jsonStr);

    // Validate the structure of parsedData
    if (parsedData && Array.isArray(parsedData.emails) && Array.isArray(parsedData.phoneNumbers)) {
      return {
        emails: parsedData.emails.filter((email: any) => typeof email === 'string'),
        phoneNumbers: parsedData.phoneNumbers.filter((phone: any) => typeof phone === 'string'),
      };
    } else {
      // Fallback if structure is not as expected, but try to find keys if they exist
      const emails = Array.isArray(parsedData?.emails) ? parsedData.emails.filter((e: unknown) => typeof e === 'string') : [];
      const phoneNumbers = Array.isArray(parsedData?.phoneNumbers) ? parsedData.phoneNumbers.filter((p: unknown) => typeof p === 'string') : [];
      
      if (emails.length > 0 || phoneNumbers.length > 0) {
        return { emails, phoneNumbers };
      }
      console.warn("Unexpected JSON structure from AI, but found partial data:", parsedData);
      // If nothing useful, treat as no contacts found
      // This could happen if the AI fails to follow format strictly
      throw new Error('AI response was not in the expected JSON format. No contacts extracted.');
    }

  } catch (error) {
    console.error("Error calling Gemini API or parsing response:", error);
    if (error instanceof Error && error.message.includes("API key not valid")) {
        throw new Error("The provided Gemini API key is not valid. Please check your configuration.");
    }
    throw new Error(`Failed to extract contacts: ${error instanceof Error ? error.message : String(error)}`);
  }
};
