
import React from 'react';
import { ExtractedContacts } from '../types';

interface ContactDisplayProps {
  contacts: ExtractedContacts;
}

const ContactItem: React.FC<{ item: string; type: 'email' | 'phone' }> = ({ item, type }) => {
  const icon = type === 'email' ? (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5 text-sky-400 mr-2 flex-shrink-0">
      <path d="M3 4a2 2 0 00-2 2v1.161l8.441 4.221a1.25 1.25 0 001.118 0L19 7.162V6a2 2 0 00-2-2H3z" />
      <path d="M19 8.839l-7.77 3.885a2.75 2.75 0 01-2.46 0L1 8.839V14a2 2 0 002 2h14a2 2 0 002-2V8.839z" />
    </svg>
  ) : (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5 text-green-400 mr-2 flex-shrink-0">
      <path fillRule="evenodd" d="M2 3.5A1.5 1.5 0 013.5 2h1.148a1.5 1.5 0 011.465 1.175l.716 3.018a1.5 1.5 0 01-1.052 1.767l-.932.373c-.606.242-.982.965-.835 1.591l.163.69c.213.902.992 1.583 1.918 1.715l.51.076c.926.137 1.696.916 1.908 1.818l.162.697c.148.626-.229 1.349-.835 1.591l-.932.373a1.5 1.5 0 01-1.052 1.767l-.716 3.018A1.5 1.5 0 013.5 18H3.495a1.5 1.5 0 01-1.49-1.355L2 16.5v-13z" clipRule="evenodd" />
      <path d="M16.445 3.085a.75.75 0 00-1.06-.03L12.5 5.568V3.5a.75.75 0 00-1.5 0v4.502c0 .414.336.75.75.75H16.5a.75.75 0 000-1.5h-2.086l2.921-2.73a.75.75 0 00-.03-1.061zM12.5 14.5a.75.75 0 01.75-.75h2.75a.75.75 0 010 1.5h-2.75a.75.75 0 01-.75-.75z" />
    </svg>

  );
  return (
    <li className="flex items-center bg-slate-700 p-3 rounded-md shadow hover:bg-slate-600/70 transition-colors">
      {icon}
      <span className="text-slate-200 truncate">{item}</span>
    </li>
  );
};

const ContactDisplay: React.FC<ContactDisplayProps> = ({ contacts }) => {
  const hasEmails = contacts.emails.length > 0;
  const hasPhoneNumbers = contacts.phoneNumbers.length > 0;

  if (!hasEmails && !hasPhoneNumbers) {
    return (
      <div className="mt-6 p-4 bg-slate-700 text-slate-300 rounded-md text-center">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mx-auto mb-2 text-slate-500">
          <path strokeLinecap="round" strokeLinejoin="round" d="M15.182 16.318A4.486 4.486 0 0012.016 15a4.486 4.486 0 00-3.198 1.318M21 12a9 9 0 11-18 0 9 9 0 0118 0zM9.75 9.75c0 .414-.168.75-.375.75S9 10.164 9 9.75s.168-.75.375-.75S9.75 9.336 9.75 9.75zm4.5 0c0 .414-.168.75-.375.75s-.375-.336-.375-.75.168-.75.375-.75.375.336.375.75z" />
        </svg>
        No contacts found in the provided text.
      </div>
    );
  }

  return (
    <div className="mt-8 space-y-8">
      {hasEmails && (
        <section>
          <h2 className="text-2xl font-semibold text-sky-400 mb-4 pb-2 border-b border-slate-700">
            <i className="heroicons-envelope w-6 h-6 inline-block mr-2 align-text-bottom"></i>
            Emails Found ({contacts.emails.length})
          </h2>
          <ul className="space-y-2">
            {contacts.emails.map((email, index) => (
              <ContactItem key={`email-${index}`} item={email} type="email" />
            ))}
          </ul>
        </section>
      )}

      {hasPhoneNumbers && (
        <section>
          <h2 className="text-2xl font-semibold text-green-400 mb-4 pb-2 border-b border-slate-700">
             <i className="heroicons-phone w-6 h-6 inline-block mr-2 align-text-bottom"></i>
            Phone Numbers Found ({contacts.phoneNumbers.length})
          </h2>
          <ul className="space-y-2">
            {contacts.phoneNumbers.map((phone, index) => (
              <ContactItem key={`phone-${index}`} item={phone} type="phone" />
            ))}
          </ul>
        </section>
      )}
    </div>
  );
};

export default ContactDisplay;
